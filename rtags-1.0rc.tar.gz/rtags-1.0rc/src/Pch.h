#ifndef Pch_h
#define Pch_h

#include <clang-c/Index.h>
#include <string>
#include <map>
#include <RTags.h>
#include <Map.h>
#include <Set.h>
#include <List.h>
#include <ByteArray.h>

#endif
