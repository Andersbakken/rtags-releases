rct
===

A set of c++ tools that provide nicer (more Qt-like) APIs on top of stl classes
released under a BSD license.
