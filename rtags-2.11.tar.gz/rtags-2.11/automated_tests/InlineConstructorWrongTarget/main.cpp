struct A
{
    A()
    {}
};

int main()
{
    return 0;
}
