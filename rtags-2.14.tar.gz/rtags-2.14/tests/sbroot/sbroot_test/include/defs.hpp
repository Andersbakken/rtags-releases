#ifndef DEFS_HPP
#define DEFS_HPP

#define TWO 2 // rc --references TWO => ../sub1/sub1.cpp:        return arg*@TWO*THREE;
              //                     => ../sub1/sub1.cpp:        return p1*@TWO;

#endif // DEFS_HPP
