
### Please mark appropriate
 - [ ] rtags (rdm/rc/rp)
 - Emacs Lisp
   - [ ] ac-rtags.el
   - [ ] company-rtags.el
   - [ ] helm-rtags.el
   - [ ] flycheck-rtags.el
   - [ ] ivy-rtags.el
   - [ ] rtags.el

### Problem description
Describe briefly the problem.

#### Expected behavior
Describe what you expected to happen.

#### Actual behavior
Describe what actually happened.

### Environment
- Your operating system:

- LLVM/Clang version:

### Feature request

Describe the feature we should add to **RTags**.
