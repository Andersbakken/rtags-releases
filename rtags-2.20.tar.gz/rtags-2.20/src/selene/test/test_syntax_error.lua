function syntax_error()
	1 2 3 4
end
