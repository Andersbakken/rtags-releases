#include "a.hpp"

template struct Y<int, int>;
template struct Y<int, char>;
template struct Y<char, int>;


