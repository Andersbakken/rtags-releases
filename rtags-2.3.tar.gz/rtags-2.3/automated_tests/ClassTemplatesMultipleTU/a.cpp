#include "a.hpp"

template struct Y<char, char>;
template struct Y<char, char, char>;
