#pragma once

void free_function();
