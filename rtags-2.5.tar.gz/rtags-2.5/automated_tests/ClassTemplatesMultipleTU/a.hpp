#pragma once

template <typename... Ts>
struct Y {};

