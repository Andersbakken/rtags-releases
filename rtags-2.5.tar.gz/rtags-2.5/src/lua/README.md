
This is Lua 5.3.2, released on 25 Nov 2015.

For installation instructions, license details, and
further information about Lua, see doc/readme.html.

