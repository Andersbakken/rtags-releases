To add a new test in this folder, just add a new folder with a
descriptive name with some sources and an `expectation.json` file with
some commands to run through `rc` and the expected resulting
locations.
